# Password Generator
**NewtonSchool Project**

- HTML
- CSS
- JavaScript

![password_generator](https://user-images.githubusercontent.com/74202040/154757344-9437a881-7151-47ec-a522-c4b83c91ce77.jpg)
